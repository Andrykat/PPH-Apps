// An object literal
var app = {
	init: function () {
		app.loadMenu();
	},

	loadMenu: function () {
		document.getElementById("menu-main-desktop").innerHTML = document.getElementById("menu-main").innerHTML;
	},

	scrollTop: function () {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	}

};
(function () {
	// your page initialization code here
	// the DOM will be available here
	app.init();
})();

$(document).ready(function () {

// CHANGE THEME


	$("a.btn-change-theme").click(function () {
		
		if ($("body").hasClass("pph-dark-theme")) {		
			$("body").removeClass("pph-dark-theme");
			$("body").addClass("pph-light-theme");
			$("body .btn-change-theme small").html("").html("Dark");
		} else {
			$("body").addClass("pph-dark-theme");
			$("body").removeClass("pph-light-theme");
			$("body .btn-change-theme small").html("").html("Light");
		}

	});	

// CHANGE MAIN TABLE


	var table = $('#table--WeeklyBalance-main').DataTable({
		dom: 'Btrp',
		searchPanes: {
            collapse: true
        },
		scrollX: true,
		scrollY: '70vh',
		scrollCollapse: true,
		fixedHeader: true,
		fixedColumns: true,
		ordering: true,
		paging: false,				
		lengthChange: true,

		"buttons":  [
		{
			extend:    'print',
			text:      '<i class="fa-solid fa-print"></i> <span class="text-xsmall">Print</div>',
			titleAttr: 'Print'
		},
		{
			extend:    'copyHtml5',
			text:      '<i class="fa-solid fa-copy"></i> <span class="text-xsmall">Copy</div>',
			titleAttr: 'Copy'
		},
		{
			extend: 	'collection',
			text:      	'<i class="bi bi-download"></i> <span class="text-xsmall">Export</div>',
			buttons: [ 
				{
					extend:    'excel',
					text:      '<i class="bi bi-file-earmark-excel"></i> Excel',

				},  
				{
					extend:    'csvHtml5',
					text:      '<i class="bi bi-filetype-csv"></i> CSV',

				},
				{
					extend:    'pdfHtml5',
					text:      '<i class="bi bi-file-earmark-pdf"></i> PDF',

				}
			],
			dropup: true
		}, 
		{
			extend:    'colvis',
			text:      '<i class="bi bi-list-check"></i>',
			titleAttr: 'Toggle Columns'
		},  
					
		],

// DATATABLE - CARD VIEW


		initComplete: function (settings, json) {

			$(".dt-buttons").append(
				'<a id="table--WeeklyBalance-cv" class="btn btn-secondary text-xsmall pt-2" href="#">Card View</a>'
			);
			$("#table--WeeklyBalance-cv").on("click", function () {
				if ($("#table--WeeklyBalance-main").hasClass("card")) {
					$(".colHeader").remove();
					$(".dataTables_scrollHead").show();
				} else {
					$(".dataTables_scrollHead").hide();
					var labels = [];
					$("#table--WeeklyBalance-main thead th").each(function () {
						labels.push($(this).text());
					});
					$("#table--WeeklyBalance-main tbody tr").each(function () {
						$(this)
							.find("td")
							.each(function (column) {
								$("<span class='colHeader'>" + labels[column] + "</span>").prependTo(
									$(this)
								);
							});
					});
				}
				$("#table--WeeklyBalance-main").toggleClass("card");
			});

		}

	});

// DATATABLE - SEARCH


var brkpoint = window.matchMedia("screen and (max-width:768px)").matches;
if (brkpoint) {		

	$(".dt-buttons").append(
		'<a href="#collapseSearchMobile" data-bs-toggle="collapse" id="table--search_mobile" class="btn btn-secondary text-xsmall pt-2 ms-1" href="#">Search</a>'
	);
}

	
    $('#table--WeeklyBalance-search').keyup(function() {
        table.search($(this).val()).draw(); // this  is for customized searchbox with datatable search feature.
    })

// DATA

	table.buttons().containers().appendTo( $('#table--WeeklyBalance-buttons') );



	// LOADING CHILD TABLE

	$('#table--WeeklyBalance-child').DataTable({
		scrollCollapse: true,
		fixedHeader: true,
		fixedColumns: true,
		paging: false,
		searching: false,
		info: false			
	});

});

// LOADING CHILD TABLE - STRUCTURE

$("a.btn-show-day-detail").click(function () {

	if ($(this).closest("tr").hasClass("HasDetails")) {
		
		$(this).closest("tr").removeClass("HasDetails");
		$(this).find(".details-mark").remove();
		$(".table-child-container").remove();

	} else {
		let tblChild = document.getElementById("WeeklyBalance-child");
		var brkpoint = window.matchMedia("screen and (max-width:768px)").matches;
		if (brkpoint) {		
			var offCanvasShowChildTable = new bootstrap.Offcanvas(document.getElementById("mobile_showChildTable"), {});
			$(tblChild).find(".table").removeClass("d-none");	
			$(".offcanvas-body").html("").html(tblChild);
			offCanvasShowChildTable.show();				
		}
		else {
			$(this).closest("tr").addClass("HasDetails");
			$(this).append('<i class="fas fa-minus-circle details-mark"></i>');

			let tr = document.createElement('tr');	
			tr.classList.add("table-child-container");		
			let td = document.createElement('td');	
			td.colSpan = "15";
			//td.classList.add("bg-neutral-50");
			td.classList.add("p-3");
			td.innerHTML = tblChild.innerHTML;
			tr.appendChild(td);
			($(this).closest("tr")).after(tr);

			$(".table-child-container").find('.table').removeClass("d-none");

		}

	}
});


// LOADING ADJUSTMENTS INFO

$("a.btn-show-adjustment").click(function() {

	if ($(this).closest("tr").hasClass("HasAdjustments")) {
		
		$(this).closest("tr").removeClass("HasAdjustments");
		$(this).html('<i class="fa fa-wrench" aria-hidden="true"></i>');
		$(".adjustment-container").remove();

	} else {
		let tblAdjustment = document.getElementById("WeeklyBalance-adjust");
		var brkpoint = window.matchMedia("screen and (max-width:768px)").matches;
		if (brkpoint) {		
			var offCanvasShowAdjustments = new bootstrap.Offcanvas(document.getElementById("mobile_showAdjustments"), {});				
			$(tblAdjustment).find('.div--WeeklyBalance-adjust-container').removeClass("d-none");				
			$(".offcanvas-body").html("").html(tblAdjustment);
			offCanvasShowAdjustments.show();					
		}
		else {

			$(this).closest("tr").addClass("HasAdjustments");
			$(this).html('<i class="fas fa-minus-circle details-mark text-red-500"></i>');

			let tr = document.createElement('tr');	
			tr.classList.add("adjustment-container");		
			let td = document.createElement('td');	
			td.colSpan = "15";
			//td.classList.add("bg-neutral-50");
			td.classList.add("p-3");
			td.innerHTML = tblAdjustment.innerHTML;
			tr.appendChild(td);
			($(this).closest("tr")).after(tr);

			$(".adjustment-container").find('.div--WeeklyBalance-adjust-container').removeClass("d-none");

		}
	}

		
})


// LOADING CHILD TABLE - STRUCTURE --- THE CHILD TABLE BY DAY IS THE SAME AS THERE

$("a.btn-show-week-detail").click(function () {


	if ($(this).closest("tr").hasClass("HasDetails")) {
		
		$(this).closest("tr").removeClass("HasDetails");
		$(this).html('<i class="fa fa-eye" aria-hidden="true"></i>');
		$(".table-child-container").remove();

	} else {
		let tblChild = document.getElementById("WeeklyBalance-child");
		var brkpoint = window.matchMedia("screen and (max-width:768px)").matches;
		if (brkpoint) {		
			var offCanvasShowChildTable = new bootstrap.Offcanvas(document.getElementById("mobile_showChildTable"), {});
			$(tblChild).find('.table').removeClass("d-none");				
			$(".offcanvas-body").html("").html(tblChild);
			offCanvasShowChildTable.show();				
		}
		else {
			$(this).closest("tr").addClass("HasDetails");
			$(this).html('<i class="fas fa-minus-circle details-mark text-red-500"></i>');
			let tr = document.createElement('tr');	
			tr.classList.add("table-child-container");		
			let td = document.createElement('td');	
			td.colSpan = "15";
			//td.classList.add("bg-neutral-50");
			td.classList.add("p-3");
			td.innerHTML = tblChild.innerHTML;
			tr.appendChild(td);
			($(this).closest("tr")).after(tr);

			$(".table-child-container").find('.table').removeClass("d-none");

		}
	}

});

// CHARTS

if (RegExp('index', 'gi').test(window.location.href)) {
	Morris.Donut({
		element: 'chart-winners',
		data: [
			{ label: 'ANDREW1', value: 316, url: 'Reports/PlayerAnalysis?PlayerName=ANDREW1&IdPlayer=629232' }, 
			{ label: 'SHAROLYNMP', value: 60, url: 'Reports/PlayerAnalysis?PlayerName=SHAROLYNMP&IdPlayer=1014993' }, 
			{ label: 'SHASHAMP', value: 15, url: 'Reports/PlayerAnalysis?PlayerName=SHASHAMP&IdPlayer=964896' }, 
			{ label: 'DIEGO1', value: 13, url: 'Reports/PlayerAnalysis?PlayerName=DIEGO1&IdPlayer=512358' }, 
			{ label: 'KRISTY', value: 2, url: 'Reports/PlayerAnalysis?PlayerName=KRISTY&IdPlayer=964548' }, 
		],
		colors: [ '#691C1A', '#992826', '#992826', '#C93532', '#DB7775' ]
	});

	Morris.Donut({
	element: 'chart-losers',
	data: [
		{ label: 'CHIPMP', value: -2111, url: 'Reports/PlayerAnalysis?PlayerName=CHIPMP&IdPlayer=925523' }, 
		{ label: 'BTT1077', value: -691, url: 'Reports/PlayerAnalysis?PlayerName=BTT1077&IdPlayer=9378' }, 
		{ label: 'MARVIN1', value: -146, url: 'Reports/PlayerAnalysis?PlayerName=MARVIN1&IdPlayer=512356' }, 
		{ label: 'LUIS12', value: -60, url: 'Reports/PlayerAnalysis?PlayerName=LUIS12&IdPlayer=709162' }, 
		{ label: 'MARCO1', value: -50, url: 'Reports/PlayerAnalysis?PlayerName=MARCO1&IdPlayer=512355' }, 
	],
	colors: [ '#1C451F', '#326335', '#418144', '#4F9E53', '#7EBD81' ]
	});
}

window.addEventListener("load", onWelcome);

/*
else if ((RegExp('template', 'gi').test(window.location.href))) {
	window.addEventListener("load",introWeeklyBalance.start());
}
*/

  //  WELCOME - INDEX

	function onWelcome() {
		var myModalWelcome = new bootstrap.Modal(document.getElementById('modal-OnWelcome'), {})
		myModalWelcome.show();
	}

	if(document.querySelector(".btn-dashboard")) {
		document.querySelector(".btn-dashboard").addEventListener("click", e => {
		$("#modal-OnWelcome").modal("hide");
		
		var collapseGS = document.getElementById('collapseGettingStarted')
		var bsCollapse = new bootstrap.Collapse(collapseGS, {
							toggle: false
						})

		bsCollapse.show()

	});
}

	
  //  ONBOARDING - INDEX

	var introDashboard = introJs().setOptions({

		/* Next button label in tooltip box */
		nextLabel: 'Next &rarr;',
		/* Previous button label in tooltip box */
		prevLabel: '&larr; Back',
		/* Skip button label in tooltip box */
		skipLabel: 'Skip',
		/* Done button label in tooltip box */
		doneLabel: 'Done',
		exitOnEsc: true,
		/* Close introduction when clicking on overlay layer? */
		exitOnOverlayClick: true,
		/* Show step numbers in introduction? */
		showStepNumbers: true,
		/* Let user use keyboard to navigate the tour? */
		keyboardNavigation: true,
		/* Show tour control buttons? */
		showButtons: true,
		/* Show tour bullets? */
		showBullets: false,
		/* Show tour progress? */
		showProgress: true,
		/* Scroll to highlighted element? */
		scrollToElement: true,
		/* Set the overlay opacity */
		overlayOpacity: 0.8,
		/* Precedence of positions, when auto is enabled */
		positionPrecedence: ["bottom", "top", "right", "left"],
		/* Disable an interaction with element? */
		disableInteraction: false,
		tooltipClass: 'onboarding-steps',
		
		steps: [	
			{
				element: document.getElementById('Intro-Step-01'),
				title: 'Navigation',
				intro: "You can check the Balance Due, Profile, Rewards and Ticker",
			},
			{
				element: document.getElementById('Intro-Step-02'),
				title: 'Main Balances',
				intro: "You can check different balances as Weekly Balance"
			},
			{
				element: document.getElementById('Intro-Step-03'),
				title: 'Main Actions',
				intro: "Different options as Player Management, Weekly Figures and others",
				position: 'top'
			},
			{
				element: document.getElementById('Intro-Step-04'),
				title: 'Top Winners - Week',
				intro: "Check the Users with most wins in the week",
				position: 'right'
			},
			{
				element: document.getElementById('Intro-Step-05'),
				title: 'Top Losers - Week',
				intro: "Check the Users with most losses in the week",
				position: 'left'
			},
			{
				element: document.getElementById('Intro-Step-06'),
				title: 'Top Decision',
				intro: "Check the Games here",
				position: 'right'
			},
			{
				element: document.getElementById('Intro-Step-07'),
				title: 'Top Open Bets',
				intro: "Check the Games here",
				position: 'left'
			}
		]
	}).oncomplete(() => document.cookie = "intro-complete=true");

	
	document.querySelector("#gsAction01").addEventListener("change", e => {
		e.preventDefault();
		if (RegExp('index', 'gi').test(window.location.href)) {
			introDashboard.start();
		} else {
			window.open("index.html","_self");
		}
	});

	document.querySelector("#gsAction02").addEventListener("change", e => {
		e.preventDefault();
		window.open("template.html","_self");
	});

	if (document.cookie.split(";").indexOf("intro-complete=true") < 0)
	window.setTimeout(start, 500);



