// An object literal


var app = {
	init: function () {
		app.loadMenu();
	},

	loadMenu: function () {
		document.getElementById("menu-main-desktop").innerHTML = document.getElementById("menu-main").innerHTML;
		//document.getElementById("betslip-desktop").innerHTML = document.getElementById("betmaker").innerHTML;
	},

	scrollTop: function () {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	}

};
(function () {
	// your page initialization code here
	// the DOM will be available here
	app.init();
})();

// CHANGE MAIN TABLE




var table = $('#table--WeeklyBalance-main').DataTable({
	dom: 'Btrp',
	searchPanes: {
		collapse: true
	},
	scrollX: true,
	scrollY: '70vh',
	scrollCollapse: true,
	fixedHeader: true,
	fixedColumns: true,
	ordering: true,
	paging: false,				
	lengthChange: true,

	"buttons":  [
	{
		extend:    'print',
		text:      '<i class="fa-solid fa-print"></i> <span class="text-xsmall">Print</div>',
		titleAttr: 'Print'
	},
	{
		extend:    'copyHtml5',
		text:      '<i class="fa-solid fa-copy"></i> <span class="text-xsmall">Copy</div>',
		titleAttr: 'Copy'
	},
	{
		extend: 	'collection',
		text:      	'<i class="bi bi-download"></i> <span class="text-xsmall">Export</div>',
		buttons: [ 
			{
				extend:    'excel',
				text:      '<i class="bi bi-file-earmark-excel"></i> Excel',

			},  
			{
				extend:    'csvHtml5',
				text:      '<i class="bi bi-filetype-csv"></i> CSV',

			},
			{
				extend:    'pdfHtml5',
				text:      '<i class="bi bi-file-earmark-pdf"></i> PDF',

			}
		],
		dropup: true
	}, 
	{
		extend:    'colvis',
		text:      '<i class="bi bi-list-check"></i>',
		titleAttr: 'Toggle Columns'
	},  
				
	],

	"columns": [
		{ "width": "12%" },
		{ "width": "12%" },
		null,
		{ "width": "12%" },
	  ],



// DATATABLE - CARD VIEW
/*

	initComplete: function (settings, json) {

		$(".dt-buttons").append(
			'<a id="table--WeeklyBalance-cv" class="btn btn-secondary text-xsmall pt-2" href="#">Card View</a>'
		);
		$("#table--WeeklyBalance-cv").on("click", function () {
			if ($("#table--WeeklyBalance-main").hasClass("card")) {
				$(".colHeader").remove();
				$(".dataTables_scrollHead").show();
			} else {
				$(".dataTables_scrollHead").hide();
				var labels = [];
				$("#table--WeeklyBalance-main thead th").each(function () {
					labels.push($(this).text());
				});
				$("#table--WeeklyBalance-main tbody tr").each(function () {
					$(this)
						.find("td")
						.each(function (column) {
							$("<span class='colHeader'>" + labels[column] + "</span>").prependTo(
								$(this)
							);
						});
				});
			}
			$("#table--WeeklyBalance-main").toggleClass("card");
		});

	}
*/
});


// DATATABLE - SEARCH


var brkpoint = window.matchMedia("screen and (max-width:768px)").matches;
if (brkpoint) {		

$(".dt-buttons").append(
	'<a href="#collapseSearchMobile" data-bs-toggle="collapse" id="table--search_mobile" class="btn btn-secondary text-xsmall pt-2 ms-1" href="#">Search</a>'
);
}


$('#table--WeeklyBalance-search').keyup(function() {
	table.search($(this).val()).draw(); // this  is for customized searchbox with datatable search feature.
})

// DATA

table.buttons().containers().appendTo( $('#table--WeeklyBalance-buttons') );





$(document).ready(function () {

// CHANGE THEME

	$("a.btn-change-theme").click(function () {
		
		if ($("body").hasClass("pph-dark-theme")) {		
			$("body").removeClass("pph-dark-theme");
			$("body").addClass("pph-light-theme");
			$("body .btn-change-theme small").html("").html("Dark");
		} else {
			$("body").addClass("pph-dark-theme");
			$("body").removeClass("pph-light-theme");
			$("body .btn-change-theme small").html("").html("Light");
		}

	});	

});

