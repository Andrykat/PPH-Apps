// An object literal


var app = {
	init: function () {
		app.loadMenu();
	},

	loadMenu: function () {
		document.getElementById("menu-main-desktop").innerHTML = document.getElementById("menu-main").innerHTML;
		document.getElementById("betslip-desktop").innerHTML = document.getElementById("betmaker").innerHTML;
	},

	scrollTop: function () {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	}

};
(function () {
	// your page initialization code here
	// the DOM will be available here
	app.init();
})();


$(document).ready(function () {

// CHANGE THEME

	$("a.btn-change-theme").click(function () {
		
		if ($("body").hasClass("pph-dark-theme")) {		
			$("body").removeClass("pph-dark-theme");
			$("body").addClass("pph-light-theme");
			$("body .btn-change-theme small").html("").html("Dark");
		} else {
			$("body").addClass("pph-dark-theme");
			$("body").removeClass("pph-light-theme");
			$("body .btn-change-theme small").html("").html("Light");
		}

	});	



});

